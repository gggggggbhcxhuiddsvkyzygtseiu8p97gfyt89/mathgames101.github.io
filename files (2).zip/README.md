# Math Games 101

Welcome to Math Games 101! This website provides links to some popular online games.

## Links to Games

- [2048](https://play2048.co/)
- [Impossible Quiz](https://www.coolmathgames.com/0-impossible-quiz)
- [1v1.lol](https://1v1.lol/)
- [Roblox (Now.gg)](https://now.gg/apps/roblox-corporation/5349/roblox.html)